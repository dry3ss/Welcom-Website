function l(mess)
{
	alert(mess);
};

$.fn.getIntegerFromId= function (selector)
{
	return parseInt(this.attr("id").replace(selector,''), 10);
};

function changeTriNewsPosition(param)
{
	//jquery selection a bit not intuitive, just to say that they start 
	//like param.selector_tri_news_title
	var true_select_title="[id^="+param.selector_tri_news_title+"]";
	var true_select_img="[id^="+param.selector_tri_news_img+"]";
	var true_select_cont="[id^="+param.selector_append_tri+"]";

	
	var $tri_titles=$(true_select_title);
	var $tri_img=$(true_select_img);
	var $tri_contents=$(true_select_cont);
	

	
	//var index_tri_img =   parseInt($tri_img   .first().attr("id").replace(param.selector_tri_news_img  ,''), 10);
	//alert("t:"+index_title+"\ni:"+index_img+"\nc:"+index_cont);
	
	//if the window was just minimized we move from the title and img onto the content
	if(param.activation_bool)
	{
		/*
		$tri_titles.css("background-color","red");
		$tri_img.css("background-color","orange");
		$tri_contents.css("background-color","blue");
		*/
		
		//--title:
		var iterators_tri_news=
		{
			title_it:$tri_titles.first(),
			img_it:$tri_img.first(),
			content_it:$tri_contents.first()
		};
		
		function putNextTitleInContent() 
		{	
			//do it before we move or we'll ahve pb
			var store_next_title_it=iterators_tri_news.title_it.nextOfType(true_select_title);
			
			
			//careful, NOT true_select_title because we want what's really "contained" in the selector 
			//not the [id^...
			var index_title = iterators_tri_news.title_it.getIntegerFromId(param.selector_tri_news_title);
				//get where we are going to append:
			var append_title_to=$("#"+param.selector_append_tri+index_title);	
			if(append_title_to.length<=0)
			{
				alert("ERROR finding content tagged: "+"#"+param.selector_append_tri+index_title+ " for putNextTitleInContent");
				return;
			}
			//l(selec+":\n"+appendto.html());
			iterators_tri_news.title_it.prependTo(append_title_to);
			//lets remove this class from the receiving end to stop a style non-uniformity problem
			append_title_to.removeClass("backgr_style");			
						
			//go to the next one
			iterators_tri_news.title_it=store_next_title_it;
			putNextTitleInContent();
		}
		putNextTitleInContent();
		
		//--img
		
		
		var index_cont =  $tri_contents.first().getIntegerFromId(param.selector_append_tri);

	}
	else
	{
		/*
		$tri_titles.css("background-color","green");
		$tri_img.css("background-color","yellow");
		$tri_contents.css("background-color","purple");
		*/
	}
};