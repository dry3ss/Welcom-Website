/*------------------------------------------
 * Gets the next element that can be selected
 * in the DOM using the (@param)selector
 -------------------------------------------*/

$.fn.nextOfType = function (selector) 
{
	var $x = $(selector);
	var ind=$x.index(this);
	
	/*
	if(ind==$x.index($x.last()))
		return;
		*/
    return $x.eq(ind + 1);
};