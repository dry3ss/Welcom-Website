<?php

namespace DR\ImageBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class DRImageBundle extends Bundle
{
}
