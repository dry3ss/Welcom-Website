<?php

namespace DR\NewsBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class DRNewsBundle extends Bundle
{
}
